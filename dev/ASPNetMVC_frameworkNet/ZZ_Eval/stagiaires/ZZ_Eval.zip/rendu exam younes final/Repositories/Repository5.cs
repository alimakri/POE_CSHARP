﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ZZ_Eval.Repositories
{
    public class Repository5
    {
        internal bool Fill()
        {
            return false;
        }

        internal object Get()
        {
            return null;
        }
    }
}