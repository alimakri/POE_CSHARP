﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ZZ_Eval.Models;

namespace ZZ_Eval.ViewModels
{
    // TODO Question 1 
    public class Question1ViewModel
    {
    }
    // -------------------------------------
}