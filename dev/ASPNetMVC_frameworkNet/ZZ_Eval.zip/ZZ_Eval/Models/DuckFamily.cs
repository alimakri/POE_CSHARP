﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZZ_Eval.Models
{
    public class DuckFamily
    {
        public string Principal { get; set; }
        public List<string> Neveus { get; set; }
    }
}